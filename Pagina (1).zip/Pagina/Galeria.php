<?php
    $conexion = new mysqli("localhost","root","","galeria");


$nombre = $_POST['Titulo'];
$descripcion = $_POST['descripcion'];
$Imagen = addslashes(file_get_contents($_FILES['Imagen']['tmp_name']));

$query = "INSERT INTO galeria(Titulo, Descripción, Imagen) VALUES('$nombre','$descripcion','$Imagen')";
$resultado = $conexion->query($query);


$rodrigo = "SELECT * FROM galeria";
$imagenes = $conexion->query($rodrigo);
while($row = $imagenes->fetch_assoc()){
    $Titulo = $row['Titulo'];
    $desc = $row['Descripción'];
    $img = base64_encode($row['Imagen']);
}


if($resultado){
    echo "si se inserto";
}
else{
    echo "no se inserto";

}

if($conexion){
}
else{
    echo "conexion no exitosa";
}
?>