window.onload = init;
function init(){

    //let imagenes =["imagen/Imagen_0.jpg","imagen/Imagen_5.jpg", "imagen/Imagen_11.jpg","imagen/Imagen_12.jpg","imagen/Imagen_13.jpg"];
    let pepe=0;
    let imagen = document.getElementsByClassName("contenedor");
    let descripcion = document.getElementsByClassName("desc");
    let titulo = document.getElementsByClassName("titulo");
  
    if (window.XMLHttpRequest)
    {
        // Objeto para IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // Objeto para IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status ==200) {


			
		}
    };
    xhttp.open("POST", "Galeria.php", true);
	var parameters="titulo="+titulo+"&url="+url+"&descripcion="+descripcion;
	
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")

    xhttp.send(parameters);
}